package com.lti.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.dao.PassengerDAO;
import com.lti.app.pojo.Passenger;

@Service
@Transactional
public class PassengerServiceImpl implements PassengerService {
@Autowired
PassengerDAO pdao;

@Override
public boolean addPassenger(Passenger passenger) {
	pdao.addPassenger(passenger);
	return true;
}

@Override
public List<Passenger> getPassenger() {
	
	return pdao.getPassengers();
}

}
