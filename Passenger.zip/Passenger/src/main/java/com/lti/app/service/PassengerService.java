package com.lti.app.service;

import java.util.List;

import com.lti.app.pojo.Passenger;

public interface PassengerService {

	public boolean addPassenger(Passenger passanger);
	public List<Passenger> getPassenger();
}
