package com.lti.app.pojo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Passenger1")
public class Passenger {

	@Id
	@Column(name="passengerid")
	private String passengerid;
	@Column(name="passengerfname")
	private String passengerfname;
	@Column(name = "passengerlname")
	private String passengerlname;
	@Column(name="passengergender")
	private String passengergender;
	@Column(name="passengerage")
	private String passengerage;
	@Column(name="passengeremailid")
	private String passengeremailid;
	@Column(name="passengerpno")
	private String passengerpno;
	@Column(name="passengerdob")
	private String passengerdob;
	@Column(name="passengeraddress")
	private String passengeraddress;
	
	public Passenger() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "Passenger [passengerid=" + passengerid + ", passengerfname=" + passengerfname + ", passengerlname="
				+ passengerlname + ", passengergender=" + passengergender + ", passengerage=" + passengerage
				+ ", passengeremailid=" + passengeremailid + ", passengerpno=" + passengerpno + ", passengerdob="
				+ passengerdob + ", passengeraddress=" + passengeraddress + "]";
	}

	public String getPassengerid() {
		return passengerid;
	}

	public void setPassengerid(String passengerid) {
		this.passengerid = passengerid;
	}

	public String getPassengerfname() {
		return passengerfname;
	}

	public void setPassengerfname(String passengerfname) {
		this.passengerfname = passengerfname;
	}

	public String getPassengerlname() {
		return passengerlname;
	}

	public void setPassengerlname(String passengerlname) {
		this.passengerlname = passengerlname;
	}

	public String getPassengergender() {
		return passengergender;
	}

	public void setPassengergender(String passengergender) {
		this.passengergender = passengergender;
	}

	public String getPassengerage() {
		return passengerage;
	}

	public void setPassengerage(String passengerage) {
		this.passengerage = passengerage;
	}

	public String getPassengeremailid() {
		return passengeremailid;
	}

	public void setPassengeremailid(String passengeremailid) {
		this.passengeremailid = passengeremailid;
	}

	public String getPassengerpno() {
		return passengerpno;
	}

	public void setPassengerpno(String passengerpno) {
		this.passengerpno = passengerpno;
	}

	public String getPassengerdob() {
		return passengerdob;
	}

	public void setPassengerdob(String passengerdob) {
		this.passengerdob = passengerdob;
	}

	public String getPassengeraddress() {
		return passengeraddress;
	}

	public void setAssenger(String passengeraddress) {
		this.passengeraddress = passengeraddress;
	}
}

	