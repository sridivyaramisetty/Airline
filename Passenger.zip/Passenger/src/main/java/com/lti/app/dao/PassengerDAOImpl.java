package com.lti.app.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.servlet.annotation.ServletSecurity.EmptyRoleSemantic;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.app.pojo.Passenger;

@Repository
public class PassengerDAOImpl implements PassengerDAO {

	@Autowired
	EntityManager eMan;

	@Override
	public boolean addPassenger(Passenger passenger) {
		eMan.persist(passenger);
		return true;
	}

	@Override
	public List<Passenger> getPassengers() {
		return eMan.createQuery("from Passenger").getResultList();
	}
	
		
	}
