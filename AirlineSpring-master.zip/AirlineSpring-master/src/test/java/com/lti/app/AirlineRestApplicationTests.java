package com.lti.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlineRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
