package com.lti.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.lti.app.dao.AdmindeleteDAO;
import com.lti.app.pojo.Admindelete;

@Service
@Transactional
public class AdmindeleteServiceImpl implements AdmindeleteService {
@Autowired
AdmindeleteDAO adao;

@Override
public boolean delAdmindelete (Admindelete admindelete) {
	adao.delAdmindeleteDAO(admindelete);
	return true;
}

@Override
public List<Admindelete> getAdmindelete() {
	return adao.getAdmindelete();
}

}

