package com.lti.app.service;

import java.util.List;

import com.lti.app.pojo.Admindelete;

public interface AdmindeleteService {

	public boolean delAdmindelete(Admindelete admindelete);
	public List<Admindelete> getAdmindelete();
}
