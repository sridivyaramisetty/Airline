package com.lti.app.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.app.dao.AiraddDAO;
import com.lti.app.pojo.Admindelete;
import com.lti.app.pojo.Airadd;

@Service
@Transactional
public class AiraddServiceImpl implements AiraddService
	{
		@Autowired
		AiraddDAO vdao; //This dependency call only interface class

		@Override
		public List<Airadd> getAiradd() {
			return vdao.getAiradd();
		}

		@Override
		public boolean addAiradd(Airadd airadd) {
			vdao.addAiradd(airadd);
			return true;
		}

		@Override
		public List<Admindelete> getAdmindelete() {
			return vdao.getAdmindelete();
		}

		@Override
		public boolean delAdmindelete(Admindelete admindelete) {
			vdao.delAdmindeleteDAO(admindelete);
			return true;
		}	
	}


