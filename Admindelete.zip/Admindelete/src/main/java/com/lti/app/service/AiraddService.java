package com.lti.app.service;

import java.util.List;

import com.lti.app.pojo.Admindelete;
import com.lti.app.pojo.Airadd;




public interface AiraddService {
	public List<Airadd> getAiradd();
	public boolean addAiradd(Airadd airadd);
	public List<Admindelete> getAdmindelete();
	public boolean delAdmindelete(Admindelete admindelete);
	

}
