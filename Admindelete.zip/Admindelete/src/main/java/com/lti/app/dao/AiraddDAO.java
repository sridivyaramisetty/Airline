package com.lti.app.dao;

import java.util.List;

import com.lti.app.pojo.Admindelete;
import com.lti.app.pojo.Airadd;


public interface AiraddDAO {
	public boolean addAiradd(Airadd airadd);
	public List<Airadd> getAiradd();
	public boolean getAdmindelete();
	public boolean delAdmindeleteDAO(Admindelete admindelete);
	List<Admindelete> getAdmindeletes();

}
