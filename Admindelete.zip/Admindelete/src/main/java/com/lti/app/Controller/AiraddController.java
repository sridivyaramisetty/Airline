package com.lti.app.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.app.pojo.Airadd;
import com.lti.app.service.AiraddService;

	
	@RestController
	@RequestMapping("/rest/api")
	//@CrossOrigin("http://localhost:4200")
	public class AiraddController 
	{
		@Autowired
		AiraddService vService;
		@GetMapping("/airadd")
		public List<Airadd> getAiradd()
		{
			return vService.getAiradd();
		}
		
		@PostMapping("/airadd")
		public boolean adAiradd(@RequestBody Airadd airadd)
		{
			return vService.addAiradd(airadd);
		}
	}


