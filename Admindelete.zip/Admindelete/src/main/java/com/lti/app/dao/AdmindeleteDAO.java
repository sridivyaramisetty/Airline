package com.lti.app.dao;

import java.util.List;

import com.lti.app.pojo.Admindelete;


public interface AdmindeleteDAO {

	public boolean delAdmindeleteDAO(Admindelete admindelete);
	public List<Admindelete> getAdmindelete();
}
