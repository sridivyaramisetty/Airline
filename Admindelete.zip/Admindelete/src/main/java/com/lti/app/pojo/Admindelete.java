package com.lti.app.pojo;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Admindelete1")
public class Admindelete {

	@Id
	@Column(name="flightid")
	private String flightid;

	@Override
	public String toString() {
		return "Admindelete [flightid=" + flightid + "]";
	}

	public String getFlightid() {
		return flightid;
	}

	public void setFlightid(String flightid) {
		this.flightid = flightid;
	}

	public Admindelete() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Admindelete(String flightid) {
		super();
		this.flightid = flightid;
	}

	
	}