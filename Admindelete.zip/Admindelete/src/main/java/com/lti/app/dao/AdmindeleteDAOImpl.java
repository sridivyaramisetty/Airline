package com.lti.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.app.pojo.Admindelete;


@Repository
public class AdmindeleteDAOImpl implements AdmindeleteDAO {
		
	@Autowired
	EntityManager eMan;

	@Override
	public boolean delAdmindeleteDAO(Admindelete admindelete) {
		eMan.persist(admindelete);
		return true;
	}

	@Override
	public List<Admindelete> getAdmindelete() {
		return eMan.createQuery("from Admindelete").getResultList();
	}

}