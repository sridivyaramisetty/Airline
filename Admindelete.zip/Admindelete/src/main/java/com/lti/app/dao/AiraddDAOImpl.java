package com.lti.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.app.pojo.Admindelete;
import com.lti.app.pojo.Airadd;




@Repository
public class AiraddDAOImpl implements AiraddDAO {
	
        @Autowired
		EntityManager eMan;

		@Override
		public boolean addAiradd(Airadd airadd) {
			eMan.persist(airadd);
			return true;
		}

		@Override
		public List<Airadd> getAiradd() {
			return eMan.createQuery("from Airadd").getResultList();
		}

		@Override
		public boolean getAdmindelete() {
			eMan.persist(admindelete);
			return true;
		}

		@Override
		public List<Admindelete> getAdmindeletes(){
			
		return eMan.createQuery("from Admindelete").getResultList();
		}

		
}

